# fortnut5 > 2022-07-13 12:18am
https://universe.roboflow.com/object-detection/fortnut5

Provided by Roboflow
License: Public Domain

